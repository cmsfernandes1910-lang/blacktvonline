# Black Streaming — site

Site estático (HTML, CSS e JavaScript puros). Não precisa de build nem de dependências.

## Estrutura

```
index.html      página principal
style.css       estilos
script.js       WhatsApp, simulador do teste e capas da TV
assets/logo.webp
favicon.svg
vercel.json     configuração da Vercel
```

## Trocar o número do WhatsApp

Abra `script.js` e altere a linha:

```js
var WHATSAPP_NUMBER = "5511994232060";
```

Use código do país + DDD + número, só dígitos.

## Publicar no GitHub

1. Crie um repositório novo em https://github.com/new (ex.: `black-streaming-site`), sem README.
2. No terminal, dentro desta pasta:

```bash
git init
git add .
git commit -m "Primeira versão do site"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/black-streaming-site.git
git push -u origin main
```

Sem terminal: no repositório, use **Add file → Upload files** e envie todos os arquivos desta pasta.

## Publicar na Vercel

1. Entre em https://vercel.com e faça login com sua conta do GitHub.
2. Clique em **Add New → Project** e importe o repositório.
3. Em **Framework Preset**, deixe **Other**. Deixe **Build Command** e **Output Directory** vazios.
4. Clique em **Deploy**.

A cada `git push` na branch `main`, a Vercel publica a nova versão automaticamente.

## Domínio próprio

Na Vercel, abra o projeto em **Settings → Domains**, adicione o domínio e siga as instruções de DNS.
