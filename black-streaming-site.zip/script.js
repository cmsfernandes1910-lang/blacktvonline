// TROQUE pelo número da empresa: código do país + DDD + número, só dígitos.
var WHATSAPP_NUMBER = "5511994232060";

document.querySelectorAll(".js-wa").forEach(function (a) {
  a.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(a.dataset.msg);
  a.target = "_blank";
  a.rel = "noopener";
});
document.getElementById("ano").textContent = new Date().getFullYear();

(function () {
  var g = document.getElementById('posters'); if (!g) return;
  var ns = 'http://www.w3.org/2000/svg';
  function el(t, a, p) { var e = document.createElementNS(ns, t); for (var k in a) e.setAttribute(k, a[k]); (p || g).appendChild(e); return e; }
  function grad(id, stops, x2, y2) {
    var d = el('linearGradient', { id: id, x1: 0, y1: 0, x2: x2, y2: y2 });
    stops.forEach(function (s) { el('stop', { offset: s[0], 'stop-color': s[1], 'stop-opacity': s[2] === undefined ? 1 : s[2] }, d); });
  }
  grad('vg', [[0, '#000', 0], [1, '#000', .85]], 0, 1);
  for (var i = 0; i < 12; i++) {
    var x = 88 + (i % 6) * 106, y = 54 + Math.floor(i / 6) * 162, l = 22 + (i * 29) % 26;
    var tone = 'hsl(215,6%,', light = tone + (l + 45) + '%)';
    grad('pg' + i, [[0, tone + (l + 16) + '%)'], [1, tone + (l - 10) + '%)']], i % 2 ? 1 : 0, 1);
    el('rect', { x: x, y: y, width: 94, height: 150, rx: 6, fill: 'url(#pg' + i + ')' });
    switch (i) {
      case 0: el('circle', { cx: x + 47, cy: y + 62, r: 24, fill: light }); el('rect', { x: x + 8, y: y + 88, width: 78, height: 3, fill: light, opacity: .6 }); break;
      case 1: el('polygon', { points: x + ',' + (y + 110) + ' ' + (x + 30) + ',' + (y + 55) + ' ' + (x + 52) + ',' + (y + 88) + ' ' + (x + 68) + ',' + (y + 66) + ' ' + (x + 94) + ',' + (y + 110), fill: light }); break;
      case 2: for (var j = 0; j < 7; j++) { var h = 30 + (j * 37) % 50; el('rect', { x: x + 4 + j * 13, y: y + 110 - h, width: 10, height: h, fill: light, opacity: .85 }); } break;
      case 3: el('polygon', { points: (x + 8) + ',' + (y + 110) + ' ' + (x + 44) + ',' + (y + 14) + ' ' + (x + 64) + ',' + (y + 14) + ' ' + (x + 28) + ',' + (y + 110), fill: light, opacity: .9 }); break;
      case 4: el('circle', { cx: x + 47, cy: y + 48, r: 14, fill: light }); el('ellipse', { cx: x + 47, cy: y + 98, rx: 30, ry: 24, fill: light }); break;
      case 5: [36, 24, 12].forEach(function (r) { el('circle', { cx: x + 47, cy: y + 62, r: r, fill: 'none', stroke: light, 'stroke-width': 4 }); }); break;
      case 6: for (var j = 0; j < 6; j++) el('rect', { x: x + 8 + j * 14, y: y + 10, width: 8, height: 100, fill: light, opacity: .3 + .12 * j }); break;
      case 7: var pts = []; for (var k = 0; k < 10; k++) { var a = Math.PI * k / 5 - Math.PI / 2, r = k % 2 ? 12 : 30; pts.push((x + 47 + r * Math.cos(a)).toFixed(1) + ',' + (y + 60 + r * Math.sin(a)).toFixed(1)); } el('polygon', { points: pts.join(' '), fill: light }); break;
      case 8: for (var j = 0; j < 4; j++) el('path', { d: 'M' + x + ' ' + (y + 50 + j * 16) + ' q23 -14 47 0 t47 0', fill: 'none', stroke: light, 'stroke-width': 3 }); break;
      case 9: el('rect', { x: x + 30, y: y + 28, width: 34, height: 84, rx: 17, fill: light }); el('rect', { x: x + 38, y: y + 38, width: 18, height: 64, rx: 9, fill: tone + (l - 8) + '%)' }); break;
      case 10: for (var r2 = 0; r2 < 5; r2++) for (var c = 0; c < 5; c++) el('circle', { cx: x + 14 + c * 16, cy: y + 24 + r2 * 16, r: 3, fill: light, opacity: .4 + .1 * ((r2 + c) % 4) }); break;
      case 11: el('polygon', { points: (x + 47) + ',' + (y + 8) + ' ' + (x + 10) + ',' + (y + 112) + ' ' + (x + 84) + ',' + (y + 112), fill: light, opacity: .5 }); el('ellipse', { cx: x + 47, cy: y + 112, rx: 37, ry: 7, fill: light }); break;
    }
    el('rect', { x: x, y: y + 60, width: 94, height: 90, rx: 6, fill: 'url(#vg)' });
    var w = 36 + (i * 13) % 34;
    el('rect', { x: x + (94 - w) / 2, y: y + 118, width: w, height: 8, rx: 2, fill: '#fff', opacity: .85 });
    el('rect', { x: x + (94 - w * .6) / 2, y: y + 132, width: w * .6, height: 4, rx: 2, fill: '#fff', opacity: .4 });
    el('rect', { x: x, y: y, width: 94, height: 150, rx: 6, fill: 'none', stroke: '#fff', 'stroke-opacity': .14 });
  }
})();

var total = 3600, left = total, timer = null;
var timeEl = document.getElementById("time"), bar = document.getElementById("bar");
var hint = document.getElementById("hint"), sim = document.getElementById("sim");
function fmt(s){ var m = Math.floor(s / 60), r = s % 60; return String(m).padStart(2,"0") + ":" + String(r).padStart(2,"0"); }
function paint(){ timeEl.textContent = fmt(left); bar.style.width = (left / total * 100) + "%"; }
sim.addEventListener("click", function () {
  if (timer) { clearInterval(timer); timer = null; left = total; paint(); sim.textContent = "Simular o teste"; hint.textContent = "Esse é o tempo do seu teste. Toque para ver como ele corre."; return; }
  sim.textContent = "Parar simulação";
  hint.textContent = "Simulação acelerada. No teste real, a hora corre normalmente.";
  timer = setInterval(function () {
    left -= 30;
    if (left <= 0) { left = 0; clearInterval(timer); timer = null; hint.textContent = "Acabou a hora. Chame a equipe e escolha seu plano!"; sim.textContent = "Reiniciar"; }
    paint();
  }, 1000);
});
paint();
